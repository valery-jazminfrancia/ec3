package com.example.ec03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ec03Application {

	public static void main(String[] args) {
		SpringApplication.run(ec03Application.class, args);
	}

}
